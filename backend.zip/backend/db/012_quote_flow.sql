-- Quote requests: "needed within N months" instead of a date, dropdown size/detail choices,
-- Finance reply details (lead time, validity), the customer's answer (accept / decline),
-- and what happens after acceptance (payments, Preparing -> Ready for Pickup / Out for Delivery -> Picked Up / Delivered).
-- shop-extras.js also does this on start, so running this by hand is optional.
ALTER TABLE quote_requests ADD COLUMN IF NOT EXISTS needed_months INT CHECK (needed_months BETWEEN 1 AND 24);
ALTER TABLE quote_requests ADD COLUMN IF NOT EXISTS specs JSONB;
ALTER TABLE quote_requests ADD COLUMN IF NOT EXISTS lead_time TEXT;
ALTER TABLE quote_requests ADD COLUMN IF NOT EXISTS valid_until DATE;
ALTER TABLE quote_requests ADD COLUMN IF NOT EXISTS responded_at TIMESTAMPTZ;
ALTER TABLE quote_requests ADD COLUMN IF NOT EXISTS response_note TEXT;
ALTER TABLE quote_requests ADD COLUMN IF NOT EXISTS paid_amount NUMERIC(14,2) NOT NULL DEFAULT 0;
ALTER TABLE quote_requests ADD COLUMN IF NOT EXISTS payments JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE quote_requests ADD COLUMN IF NOT EXISTS progress JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE quote_requests ADD COLUMN IF NOT EXISTS received_by TEXT;
ALTER TABLE quote_requests DROP CONSTRAINT IF EXISTS quote_requests_status_check;
ALTER TABLE quote_requests ADD CONSTRAINT quote_requests_status_check
  CHECK (status IN ('new','quoted','accepted','declined','preparing','ready','completed','closed'));
-- payment method chosen when the quote is accepted (online customer picks one; cashier/walk-in quotes are automatically 'Pay on pickup' / 'Pay on delivery')
ALTER TABLE quote_requests ADD COLUMN IF NOT EXISTS pay_method TEXT;
ALTER TABLE quote_requests ADD COLUMN IF NOT EXISTS xendit_invoice_id TEXT;   -- online payment (Xendit) of an accepted quote
ALTER TABLE quote_requests ADD COLUMN IF NOT EXISTS xendit_external_id TEXT;

-- Quote requests: "Needed by" is a date again (picked with a date picker: tomorrow up to 6 months ahead, checked by the server).
-- New requests are saved in needed_by (a DATE column the table already had). needed_months stays only so older requests keep showing
-- "within N months" in the lists. Nothing is deleted or converted. shop-extras.js also makes sure the column exists on start, so
-- running this by hand is optional.
ALTER TABLE quote_requests ADD COLUMN IF NOT EXISTS needed_by DATE;
